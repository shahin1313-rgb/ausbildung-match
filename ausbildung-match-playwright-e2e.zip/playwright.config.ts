import { defineConfig, devices } from '@playwright/test';

const baseURL = process.env.E2E_BASE_URL ?? 'http://127.0.0.1:8000';

if (/^(https?:\/\/)?(www\.)?[^/]+\.(com|de|ir|net|org)(\/|$)/i.test(baseURL) && !process.env.ALLOW_REMOTE_E2E) {
  throw new Error('Remote E2E target blocked. Use a local/test URL or explicitly set ALLOW_REMOTE_E2E=1.');
}

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: false,
  retries: 0,
  reporter: [['list'], ['html', { outputFolder: 'playwright-report', open: 'never' }]],
  use: {
    baseURL,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  outputDir: 'test-results',
});
