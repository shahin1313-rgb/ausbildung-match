import { expect, test } from '@playwright/test';

test('صفحه ورود در مرورگر باز می‌شود', async ({ page }) => {
  const loginPath = process.env.E2E_LOGIN_PATH ?? '/login';
  const response = await page.goto(loginPath, { waitUntil: 'domcontentloaded' });

  expect(response, 'سرور پاسخی برنگرداند').not.toBeNull();
  expect(response!.status(), 'صفحه ورود خطای HTTP دارد').toBeLessThan(400);
  await expect(page.locator('body')).toBeVisible();
  await expect(page.locator('input[type="email"], input[name="email"]')).toBeVisible();
  await expect(page.locator('input[type="password"], input[name="password"]')).toBeVisible();
});
